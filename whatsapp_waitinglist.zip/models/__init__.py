# -*- coding: utf-8 -*-

from . import res_config_settings
from . import waiting_list_notification
from . import waiting_list
from . import whatsapp_composer
from . import whatsapp_template
