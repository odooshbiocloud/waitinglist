# -*- coding: utf-8 -*-

from . import waiting_list_allergen
from . import waiting_list
from . import res_partner
from . import res_config_settings
from . import waiting_list_customer_wizard