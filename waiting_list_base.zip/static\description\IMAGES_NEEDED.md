# Images Required for Odoo App Store

## 📸 Required Images Checklist

### 1. Module Icon (REQUIRED) ⚠️
**File:** `icon.png`
- **Location:** `static/description/icon.png`
- **Size:** 256x256 pixels (recommended)
- **Format:** PNG with transparent background
- **Design:** 
  - Should represent waiting list/restaurant queue management
  - Suggested elements: clipboard with list, people waiting, table icon
  - Use your brand colors (purple/blue gradient suggested: #667eea to #764ba2)
  - Keep it simple and recognizable at small sizes
  - This icon appears in:
    - Odoo Apps menu
    - App Store listing
    - Module installation screen

### 2. Banner Image (HIGHLY RECOMMENDED) 🎨
**File:** `banner.png` or `banner.jpg`
- **Location:** `static/description/banner.png`
- **Size:** 560x280 pixels
- **Format:** PNG or JPG
- **Design:**
  - Eye-catching header for your App Store page
  - Should include:
    - Module name: "Restaurant Waiting List"
    - Tagline: "Transform Your Queue Management"
    - Key feature icons or badges (Safety First, Multi-Branch, Analytics)
  - Use gradient background (#667eea to #764ba2)
  - Professional typography
  - High contrast for readability

### 3. Screenshots (REQUIRED - Minimum 3-5) 📷
**Files:** `screenshot_1.png`, `screenshot_2.png`, etc.
- **Location:** `static/description/screenshot_X.png`
- **Size:** 1920x1080 pixels (or 1280x720 minimum)
- **Format:** PNG (preferred) or JPG
- **Recommended Screenshots:**

#### Screenshot 1: Dashboard View
- Show the main waiting list dashboard
- Display KPIs and metrics
- Real-time queue with customer names (use dummy data)
- Highlight: Overview of the entire system

#### Screenshot 2: Waiting List Management
- Main waiting list view (tree or kanban)
- Show status indicators (Waiting, Ready, Seated)
- Display customer count, wait times
- Highlight: Core functionality

#### Screenshot 3: Allergen Management & Safety
- Customer form with allergen warnings
- Visual alert/warning indicators
- Allergen profile section
- Highlight: Unique safety feature

#### Screenshot 4: Table Management
- Table configuration view
- Branch assignment
- Capacity settings
- Highlight: Table organization

#### Screenshot 5: Customer Profile with Allergens
- res.partner form with allergen section
- Visit history
- Customer categories
- Highlight: Customer intelligence

#### Screenshot 6: Settings Configuration (Optional)
- Configuration panel
- Branch setup
- Module settings
- Highlight: Easy setup

### 4. Additional Assets (Optional but Recommended)

#### Feature Icons
Create small icons (64x64) for:
- Smart Queue Management
- Multi-Branch Operations
- Allergen Safety
- Analytics & Reporting
- Security

#### Video Demo (Optional)
- 1-2 minute walkthrough
- Show key features in action
- Upload to YouTube/Vimeo and link in description

## 🎨 Design Guidelines

### Color Palette
- Primary: #667eea (purple-blue)
- Secondary: #764ba2 (purple)
- Success: #28a745 (green)
- Warning: #ffc107 (yellow/gold)
- Danger: #dc3545 (red - for allergen alerts)
- Info: #17a2b8 (cyan)

### Typography
- Headers: Bold, professional fonts (Segoe UI, Roboto, Open Sans)
- Body: Clean, readable fonts
- Ensure good contrast for readability

### Screenshot Tips
1. **Use Demo Data:**
   - Use realistic but fake customer names
   - Include varied scenarios (different statuses, times, etc.)
   - Show the module in action with populated data

2. **Highlight Key Features:**
   - Use arrows or callouts to point out important features
   - Add brief captions explaining what's shown
   - Show different views (form, list, kanban, dashboard)

3. **Professional Quality:**
   - High resolution (no blurry images)
   - Clean, organized interface
   - No personal/sensitive information
   - Consistent Odoo theme throughout

4. **Show Real Use Cases:**
   - Busy restaurant with multiple customers waiting
   - Hostess assigning tables
   - Allergen warnings in action
   - Reports and analytics

## 📝 How to Create Screenshots

### Method 1: Browser Screenshots
1. Set up demo environment with sample data
2. Open Odoo in browser
3. Navigate to feature you want to capture
4. Use browser full-screen mode (F11)
5. Take screenshot:
   - Windows: Win + Shift + S
   - Mac: Cmd + Shift + 4
   - Or use tools like Snagit, ShareX, Lightshot

### Method 2: Professional Tools
- **Figma/Adobe XD:** Create mockups
- **Snagit:** Advanced screenshot tool
- **OBS Studio:** Record video demos
- **Canva:** Create banner and icon

### Method 3: Odoo Screenshot Module
- Some Odoo modules can help take clean screenshots
- Ensure they capture the right resolution

## 🚀 Quick Creation Guide

### For Icon (icon.png):
1. Use Canva, Figma, or Adobe Illustrator
2. Create 256x256 canvas
3. Design simple icon with:
   - Clipboard + people icon
   - Or table + queue icon
   - Use purple gradient (#667eea to #764ba2)
4. Export as PNG with transparency
5. Save as `static/description/icon.png`

### For Banner (banner.png):
1. Create 560x280 canvas
2. Add gradient background (#667eea to #764ba2)
3. Add text:
   - "Restaurant Waiting List" (large, bold, white)
   - "Professional Queue Management" (smaller, white)
4. Add 3-4 feature badges/icons
5. Export as PNG or JPG
6. Save as `static/description/banner.png`

### For Screenshots:
1. Install module in demo environment
2. Add realistic demo data (customers, tables, allergens)
3. Navigate to each view
4. Take clean, high-resolution screenshots
5. Optionally add annotations/highlights
6. Resize to 1920x1080 if needed
7. Save as `screenshot_1.png`, `screenshot_2.png`, etc.

## ✅ Final Checklist Before Submission

- [ ] icon.png (256x256) exists in static/description/
- [ ] banner.png (560x280) exists in static/description/
- [ ] At least 3 screenshots exist (1920x1080)
- [ ] All images are professional quality (no blur, good lighting)
- [ ] Screenshots show real functionality with demo data
- [ ] No personal/sensitive information in screenshots
- [ ] Images are properly named (icon.png, screenshot_1.png, etc.)
- [ ] index.html is updated and looks good
- [ ] __manifest__.py has correct information
- [ ] README.md is complete

## 📧 Need Help?

If you need help creating these images:
1. **Hire a Designer:** Fiverr, Upwork (budget: $50-200)
2. **Use Templates:** Canva has Odoo module templates
3. **DIY Tools:** Figma (free), Canva (free tier), GIMP (free)

## 🎯 Priority Order

1. **High Priority (Must Have):**
   - icon.png
   - 3-5 screenshots
   - index.html (✅ Already done)

2. **Medium Priority (Should Have):**
   - banner.png
   - Additional screenshots showing all features

3. **Low Priority (Nice to Have):**
   - Video demo
   - Feature icons
   - Animated GIFs

---

**Remember:** First impressions matter! Quality images can significantly increase your module's downloads and sales.
